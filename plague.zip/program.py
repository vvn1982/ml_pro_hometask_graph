# -*- coding: utf-8 -*-
"""
Created on Tue Jul 12 21:41:14 2022

@author: vvn
"""
import numpy as np, pandas as pd
import random
import networkx as nx

#%% 
d = pd.read_csv('preproc_data/airports200801.csv')
print('Dataset shape: ', d.shape)

#%%

def get_infected(infection_probability: float):
    """
    Taking flight from infected airport, destination aiport had been 
    infected or not.

    Parameters
    ----------
    infection_probability : float, 0..1
        Airport infection probability.

    Returns
    -------
    Boolean
        True - airport was infected, False - was not infected.

    """
    return True if random.random() < infection_probability else False


#%% Даты перелетов в датасете
fly_dates = d['Fly_date'].drop_duplicates().sort_values().reset_index(drop=True)

#%% Города вылета и прилета
origin_cities = d['Origin_city'].drop_duplicates().sort_values().reset_index(drop=True)
dest_cities = d['Destination_city'].drop_duplicates().sort_values().reset_index(drop=True)
# все города вылета и прилета
cities = pd.concat([dest_cities, origin_cities]).drop_duplicates().sort_values().reset_index(drop=True)

# Певый зараженный город - рандом либо первый в списке городов вылета
# first_infected_city = origin_cities[random.randint(0, len(origin_cities))]
first_infected_city = origin_cities[0]
print(f'first_infected_city {first_infected_city}')

n_cities, n_origin_cities, n_dest_cities = len(cities), len(origin_cities), len(dest_cities)
print('n_cities: {}, n_origin_cities: {}, n_dest_cities : {}'.format(n_cities, n_origin_cities, n_dest_cities) )


#%% Симуляция заражения с сохранением результатов в infection_history и статистики в inf_stat

infection_history_columns = ['city', 'simulation_case', 'infection_proba', 
           'infected', 'infection_date']

infection_history = None

inf_stat_columns = ['simulation_case', 'infection_proba', 'date',
                    'inf_cities', 'total_inf_cities', 'inf_rate', 'total_inf_rate']
inf_stat = pd.DataFrame(
    columns=inf_stat_columns
    )

#%% Setup of simulation cases
# Выводить print-комментарии в консоль 
logging = True
infection_probability_cases = [0.01, 0.05, 0.1, 0.5, 1.]
# infection_probability_cases = [.11,]
number_of_simulation_cases_for_each_infection_proba = 10

#%% Расчет модели 5 значений вероятности заражения, 10 симуляций
for p in infection_probability_cases:
    for simulation_case in range(1, number_of_simulation_cases_for_each_infection_proba + 1):
        # Временный DataFrame c историей заражений в одном симкейсе
        inf_hist_ = pd.DataFrame(
            index=pd.Index(cities),
            columns = infection_history_columns
            )
        # Идентификаторы - вероятность заражения и номер симуляции
        inf_hist_['simulation_case'] = simulation_case
        inf_hist_['infection_proba'] = p
        if logging:
            print('Infection_probability: {}. Simulation case: {}'
                  .format(p, simulation_case))
        # Инициализация - первые зараженные города
        inf_hist_.loc[first_infected_city, 'infected'] = True
        inf_hist_.loc[first_infected_city, 'infection_date'] = fly_dates[0]
        
        for date in fly_dates:
            print(f'Current date: {date}')
            # Итерация по датасету 
            for row in d.itertuples():
                origin_city_ = getattr(row, 'Origin_city')
                dest_city_ = getattr(row, 'Destination_city')
                if inf_hist_.loc[dest_city_, 'infected'] == True:
                    continue
                is_infected = get_infected(p)
                if ((inf_hist_.loc[origin_city_, 'infected'] == True) and is_infected):
                    inf_hist_.loc[dest_city_, 'infected'] = True
                    inf_hist_.loc[dest_city_, 'infection_date'] = date

            number_of_cities_infected = inf_hist_.query('infected == True')['infection_date'].count()
            number_of_cities_infected_at_date = inf_hist_.query('infection_date == @date')['infection_date'].count()
            if logging:
                print('The number of infected cities at {}: {}'
                      .format(date, number_of_cities_infected_at_date))
                print('Total count of infected cities: {} of {}'
                      .format(number_of_cities_infected, n_cities ))
            
            # Статистика симуляции на дату - временный датафрейм-строка inf_stat_ 
            inf_stat_ = pd.DataFrame(columns=inf_stat_columns)
            inf_stat_.loc[0, 'date'] = date
            inf_stat_['simulation_case'] = simulation_case
            inf_stat_['infection_proba'] = p
            inf_stat_['inf_cities'] = number_of_cities_infected_at_date
            inf_stat_['total_inf_cities'] = number_of_cities_infected
            inf_stat_['inf_rate'] = inf_stat_['inf_cities'] / n_cities
            inf_stat_['total_inf_rate'] = inf_stat_['total_inf_cities'] / n_cities
            
            # Объединение inf_stat_ в общую статистику inf_stat
            inf_stat = pd.concat(
                [inf_stat, inf_stat_],
                axis='rows',
                )
            
        # Объединение датафрейма с историей симуляций
        inf_hist_['city'] = inf_hist_.index.to_list()
        inf_hist_ = inf_hist_.reset_index(drop=True)
        if infection_history is None:
            infection_history = inf_hist_
        else:
            infection_history = pd.concat(
                [infection_history, inf_hist_], 
                axis='rows',            
                )    
               
#%% Сохранение результатов
infection_history.to_excel('results/infection_history_5p_10c.xls')
inf_stat.to_excel('results/infection_statistics_5p_10c.xls')

#%% загрузка результатов
infection_history.to_excel('results/infection_history_.xls')
inf_stat.to_excel('results/infection_statistics.xls')
#%% Графики
for p in infection_probability_cases:
    d_ = inf_stat.query('infection_proba == @p')
    d_.plot.scatter(x='date', y='total_inf_cities', 
                    c='simulation_case', cmap='tab20', label=f'Inf_proba={p}')
#%%
inf_stat_averaged = inf_stat.groupby(['infection_proba', 'date']).mean().reset_index()
inf_stat_averaged['infection_proba'] = inf_stat_averaged['infection_proba'].astype('category')
inf_stat_averaged.plot.scatter(x='date', y='total_inf_rate', 
                c='infection_proba', cmap='Set1')

#%%
g = d.loc[:, ['Origin_city', 'Destination_city', 'Fly_date', 'Flights']]
flights_count = g.groupby(['Fly_date', 'Origin_city', 'Destination_city']).count()
flights_count.dropna(inplace=True)
flights_count_back = g.groupby(['Fly_date', 'Destination_city', 'Origin_city']).count()
flights_count_back.dropna(inplace=True)
flights_count_back.index.names = ['Fly_date', 'Origin_city', 'Destination_city']
flights = pd.merge(flights_count, flights_count_back, how='outer', 
                    left_index=True, right_index=True, suffixes=['_from', '_back'])
flights = flights.fillna(0)
flights['Total'] = flights['Flights_from'] + flights['Flights_back']
flights['Total_all_dates'] = flights['Total'].sum()
flights['weight'] = flights['Total'] / flights['Total'].sum()
flights['Total_date'] = flights.groupby('Fly_date')['Total'].transform('sum')
flights['weight_date'] = flights['Total'] / flights['Total_date']

flights_all = flights.loc[:, 'weight'].reset_index()
flights_weighted_by_dates = flights.loc[:, 'weight_date'].reset_index()


#%% Построение графа и расчет метрик
G = nx.from_pandas_edgelist(flights_all, 
                            source='Origin_city', 
                            target='Destination_city',
                            edge_attr='weight')

nx_clustering_weighted = nx.cluster.clustering(G, weight='weight')
nx_cl_w = pd.DataFrame(nx_clustering_weighted.values(), 
                     index=nx_clustering_weighted.keys(), 
                     columns=['clustering_w']
                     )
nx_clustering = nx.cluster.clustering(G)
nx_cl = pd.DataFrame(nx_clustering.values(), 
                     index=nx_clustering.keys(), 
                     columns=['clustering']
                     )

nx_degree_weighted = dict(nx.degree(G, weight='weight'))
nx_dg_w = pd.DataFrame(nx_degree_weighted.values(), 
                     index=nx_degree_weighted.keys(),
                     columns=['degree_w']
                     )
nx_degree = dict(nx.degree(G))
nx_dg = pd.DataFrame(nx_degree.values(), 
                     index=nx_degree.keys(),
                     columns=['degree']
                     )
nx_betweenness_centrality = nx.betweenness_centrality(G, weight='weight')
nx_bc_w = pd.DataFrame(nx_betweenness_centrality.values(), 
                     index=nx_betweenness_centrality.keys(),
                     columns=['bc_w'])

nx_betweenness_centrality = nx.betweenness_centrality(G)
nx_bc = pd.DataFrame(nx_betweenness_centrality.values(), 
                     index=nx_betweenness_centrality.keys(),
                     columns=['bc'])
inf_graph = pd.concat([nx_cl, nx_dg, nx_bc, nx_cl_w, nx_dg_w, nx_bc_w], axis=1)


#%% Симуляция заражения с сохранением результатов в infection_history и статистики в inf_stat

infection_history_columns = ['city', 'simulation_case', 'infection_proba', 
           'infected', 'infection_date']

infection_history = pd.DataFrame( 
    columns=infection_history_columns
    )

inf_stat_columns = ['simulation_case', 'infection_proba', 'date',
                    'inf_cities', 'total_inf_cities', 'inf_rate', 'total_inf_rate']
inf_stat = pd.DataFrame(
    columns=inf_stat_columns
    )

#%% Расчет модели заражения 50 кейсов с вер. заражения 0.05
logging = True
infection_probability_cases = [0.05,]
number_of_simulation_cases_for_each_infection_proba = 50
inf_hist = None

for p in infection_probability_cases:
    for simulation_case in range(1, number_of_simulation_cases_for_each_infection_proba + 1):
        # Временный DataFrame c историей заражений в одном симкейсе
        inf_hist_ = pd.DataFrame(
            index=pd.Index(cities),
            columns = infection_history_columns
            )
        # Идентификаторы - вероятность заражения и номер симуляции
        inf_hist_['simulation_case'] = simulation_case
        inf_hist_['infection_proba'] = p
        if logging:
            print('Infection_probability: {}. Simulation case: {}'
                  .format(p, simulation_case))
        # Инициализация - первые зараженные города
        inf_hist_.loc[first_infected_city, 'infected'] = True
        inf_hist_.loc[first_infected_city, 'infection_date'] = fly_dates[0]
        
        for date in fly_dates:
            if logging:
                print(f'Current date: {date}')
            # Итерация по датасету 
            for row in d.itertuples():
                origin_city_ = getattr(row, 'Origin_city')
                dest_city_ = getattr(row, 'Destination_city')
                if inf_hist_.loc[dest_city_, 'infected'] == True:
                    continue
                is_infected = get_infected(p)
                if ((inf_hist_.loc[origin_city_, 'infected'] == True) and is_infected):
                    inf_hist_.loc[dest_city_, 'infected'] = True
                    inf_hist_.loc[dest_city_, 'infection_date'] = date

            number_of_cities_infected = inf_hist_.query('infected == True')['infection_date'].count()
            number_of_cities_infected_at_date = inf_hist_.query('infection_date == @date')['infection_date'].count()
            if logging:
                print('The number of infected cities at {}: {}'
                      .format(date, number_of_cities_infected_at_date) + 
                      '. Total count of infected cities: {} of {}'
                      .format(number_of_cities_infected, n_cities ))
            
            # Статистика симуляции на дату - временный датафрейм-строка inf_stat_ 
            inf_stat_ = pd.DataFrame(columns=inf_stat_columns)
            inf_stat_.loc[0, 'date'] = date
            inf_stat_['simulation_case'] = simulation_case
            inf_stat_['infection_proba'] = p
            inf_stat_['inf_cities'] = number_of_cities_infected_at_date
            inf_stat_['total_inf_cities'] = number_of_cities_infected
            inf_stat_['inf_rate'] = inf_stat_['inf_cities'] / n_cities
            inf_stat_['total_inf_rate'] = inf_stat_['total_inf_cities'] / n_cities
            
            # Объединение inf_stat_ в общую статистику inf_stat
            inf_stat = pd.concat(
                [inf_stat, inf_stat_],
                axis='rows',
                )
            
        # Объединение датафрейма с историей симуляций
        inf_hist_['city'] = inf_hist_.index.to_list()
        inf_hist_ = inf_hist_.reset_index(drop=True)
        if inf_hist is None:
            inf_hist = inf_hist_.copy()
        else:
            inf_hist = pd.concat(
                [inf_hist, inf_hist_], 
                axis='rows',            
                )                       
#%% Сохранение результатов
inf_hist.to_excel('results/infection_history_50_05.xls')
inf_stat.to_excel('results/infection_statistics_50_05.xls')

#%% Графики scatter plots всех кейсов - доли зараженных городов от времени - для модели 0.05-50
for p in infection_probability_cases:
    d_ = inf_stat.query('infection_proba == @p')
    d_.plot.scatter(x='date', y='total_inf_cities', 
                    c='simulation_case', cmap='tab20', label=f'Inf_proba={p}')
#%% График scatter plot средней доли зараженных городов от времени - для модели 0.05-50
inf_stat_averaged = inf_stat.groupby(['infection_proba', 'date']).mean().reset_index()
inf_stat_averaged['infection_proba'] = inf_stat_averaged['infection_proba'].astype('category')
inf_stat_averaged.plot.scatter(x='date', y='total_inf_rate', 
                c='infection_proba', cmap='Set1')

#%% Расчет столбца - времени до заражения в месяцах
ih_05 = inf_hist.copy().dropna()
ih_05['inf_date'] = pd.to_datetime(ih_05['infection_date'])
ih_05['delta_t_inf'] = (ih_05['inf_date'] - ih_05['inf_date'].min()) / np.timedelta64(1, 'M')
ih_05['delta_t_inf'] = ih_05['delta_t_inf'].astype(int)

#%% Расчет медианного времени до заражения города и объединение в единый датафрейм с метриками графа

i_median_time = ih_05.groupby(['city'])['delta_t_inf'].median()
inf_gr = pd.concat(
    [i_median_time, inf_graph],
    axis=1
    )

#%% Scatter plots зависимостей метрик графа от времени до заражения города
inf_gr.plot.scatter('delta_t_inf', 'clustering')
inf_gr.plot.scatter('delta_t_inf', 'degree')
inf_gr.plot.scatter('delta_t_inf', 'bc')
inf_gr.plot.scatter('delta_t_inf', 'clustering_w')
inf_gr.plot.scatter('delta_t_inf', 'degree_w')
inf_gr.plot.scatter('delta_t_inf', 'bc_w')

#%% Корреляция Спирмана
corr_matrix = inf_gr.corr(method='spearman')

