# -*- coding: utf-8 -*-
"""
Created on Tue Jul 12 22:23:27 2022

@author: vvn
"""

import numpy as np, pandas as pd

d = pd.read_csv('raw_data/Airports2.csv')
# f = pd.read_csv('raw_data/2008.csv')
dates = d.query('Fly_date >= "2008-01-01"')['Fly_date'].unique()
start_date = '2008-01-01'
end_date = '2008-12-01'
d_2008 = d.query('(Fly_date >= @start_date) & (Fly_date <= @end_date)')
d_2008.to_csv('preproc_data/airports200801.csv')

